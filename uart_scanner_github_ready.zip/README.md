# UART Scanner for Junsun 8227L

Project ready to push to GitHub. Use the provided GitHub Actions workflow to build APK.
